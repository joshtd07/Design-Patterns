package decorator;

public class Car extends Vehicle {
    public Car() {
        super(FileReader.getLines(fileName:C:/Users/Josh/Downloads/vehicle.txt));
    }
}