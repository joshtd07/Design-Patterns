package decorator;

import java.util.ArrayList;

public class Paint extends VehicleDecorator {
    private Vehicle vehicle;

    public Paint(Vehicle vehicle, String color) {
        super(FileReader.getLines(fileName:C:/Users/Josh/Downloads/paint.txt));

        this.vehicle = vehicle;
        ArrayList<String> copy = new ArrayList<String>();
        copy.add(tree.lines.toString());
        copy.add(lines.toString());
        integrateDecor(copy);
    }
}